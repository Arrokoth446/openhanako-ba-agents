---
name: knowledge-distiller
slug: knowledge-distiller
version: 1.0.0
description: 从对话或文档中抽取高价值知识，生成标准 markdown 文件，写入本地知识库。当用户说"入库""沉淀""提炼知识""存进知识库"时触发。
default-enabled: false
---

# Knowledge Distiller

从对话或文档内容中抽取高价值知识，生成标准 markdown 文件，写入知识库。

## 知识库位置

`/Users/max-mac/Desktop/knowledge/`

目录结构：

```
inbox/          待审候选（principle/preference 首次出现，或低置信内容）
facts/          事实：API、结构、配置、技术细节
procedures/     流程：步骤、操作序列、工作流
lessons/        教训：踩坑、排障、经验
principles/     原则：方法论、设计决策、底层判断
preferences/    偏好：风格、习惯、个人规则
```

## 知识类型

只使用以下 5 种：

| 类型 | 定义 | 举例 |
|------|------|------|
| `fact` | 可验证的客观信息 | API 地址、仓库结构、配置项、版本号 |
| `procedure` | 有明确步骤的操作序列 | PR 提交流程、部署步骤、页面制作流程 |
| `lesson` | 踩坑后得出的经验 | 某个 bug 的根因和排查路径 |
| `principle` | 跨场景的方法论或设计决策 | "偶发好思路不固化成常驻流程" |
| `preference` | 个人的风格和习惯偏好 | "白色简洁风""标题要具体拒绝泛化" |

## 入库判定

### 必须入库（满足任意一条）
1. 踩坑后总结的有效排障路径
2. 多次重复出现的稳定偏好或原则
3. 有明确步骤、可直接复用的流程
4. 对特定项目长期有用的技术事实
5. 纠正了之前错误认知的内容

### 不入库（满足任意一条）
1. 纯情绪或闲聊
2. 一次性临时想法，无复用价值
3. 未经验证的猜测
4. 和已有知识完全重复
5. 过于泛泛，缺乏具体结论

### 需人工确认
1. 新出现的 `principle` 或 `preference`（首次出现）
2. 可能与已有知识冲突的内容
3. 置信度低于 0.7 的内容

## 执行流程

1. 读取用户提供的对话/文档内容
2. 扫描知识库现有 INDEX.md，了解已有知识（避免重复）
3. 抽取候选知识，逐条判定是否入库
4. 生成标准 markdown 文件
5. 写入对应目录
6. 更新对应目录的 INDEX.md
7. 向用户汇报：抽取了几条、入库了几条、丢弃了几条、需确认几条

## 文件格式

文件命名：`{类型缩写}-{简短英文连字符标题}.md`

类型缩写：`fact` / `proc` / `lesson` / `princ` / `pref`

文件内容：

```markdown
---
id: {类型}-{简短英文连字符标题}
title: {中文标题，具体不泛化}
type: {fact|procedure|lesson|principle|preference}
tags: [相关标签]
project: {相关项目，如适用}
confidence: {high|medium|low}
status: {active|pending}
created: {YYYY-MM-DD}
---

## 结论

{核心判断或结论}

## 触发条件

{什么时候会用到这条知识，如适用}

## 步骤

{具体操作步骤，仅 procedure 类型必填}

## 边界

{不适用的情况、反例、局限}

## 来源

{对话日期/文档名称/issue 编号等}
```

## 写入规则

- 高置信 `fact` / `procedure` / `lesson`：直接写入对应目录
- `principle` / `preference`：写入 `inbox/`，status 标为 `pending`
- 低置信内容：写入 `inbox/`，status 标为 `pending`
- 一条知识只表达一个核心判断
- 不自动修改或删除已有文件
- 不自动 git 操作

## 向用户汇报的格式

```
📋 知识提炼完成

✅ 入库 {n} 条：
- [{类型}] {标题}
- ...

📬 待确认 {n} 条（已写入 inbox）：
- [{类型}] {标题}
- ...

🗑 丢弃 {n} 条：
- {原因简述}
```
